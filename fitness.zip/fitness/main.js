// Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
        const mobileMenu = document.getElementById('mobileMenu');
        const navLinks = document.getElementById('navLinks');
        const menuIcon = document.getElementById('menuIcon');
    
    // Toggle menu function
    function toggleMenu() {
        navLinks.classList.toggle('active');
        
        // Change icon between hamburger and X
        if (navLinks.classList.contains('active')) {
            menuIcon.classList.remove('fa-bars');
            menuIcon.classList.add('fa-times');
        } else {
            menuIcon.classList.remove('fa-times');
            menuIcon.classList.add('fa-bars');
        }
    }
    
    // Mobile menu click event
    mobileMenu.addEventListener('click', toggleMenu);
    
    // Close menu when clicking on a link (for single page navigation)
    const navItems = document.querySelectorAll('.nav-links a');
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            if (window.innerWidth <= 768) {
                toggleMenu();
            }
        });
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!navLinks.contains(event.target) && !mobileMenu.contains(event.target)) {
            navLinks.classList.remove('active');
            menuIcon.classList.remove('fa-times');
            menuIcon.classList.add('fa-bars');
        }
    });
    
    // Close menu on window resize if it becomes desktop view
    window.addEventListener('resize', function() {
        if (window.innerWidth > 768) {
            navLinks.classList.remove('active');
            menuIcon.classList.remove('fa-times');
            menuIcon.classList.add('fa-bars');
        }
    });
 });
    document.querySelector('.logo').addEventListener('click', function(e) {
        // Only do this if we're not already on the homepage
        if (window.location.pathname !== '/index.html' && 
            window.location.pathname !== '/') {
            e.preventDefault();
            document.body.style.opacity = '0.5'; // Fade out effect
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 300); // Match this with your CSS transition time
        }
    });
    // Tab switching functionality
        const tabs = document.querySelectorAll('.auth-tab');
        const forms = document.querySelectorAll('.form-container');
        
        tabs.forEach(tab => {
            tab.addEventListener('click', function() {
                // Update tabs
                tabs.forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                
                // Update forms
                const tabName = this.getAttribute('data-tab');
                forms.forEach(form => {
                    form.classList.remove('active');
                    if (form.id === `${tabName}Form`) {
                        form.classList.add('active');
                    }
                });
            });
        });
        
        // Switch between login and signup
        document.getElementById('switchToSignup').addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelector('.auth-tab[data-tab="signup"]').click();
        });
        
        document.getElementById('switchToLogin').addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelector('.auth-tab[data-tab="login"]').click();
        });
        
        // Form validation and submission
        document.getElementById('login').addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;
            
            // In a real app, you would send this to your backend
            console.log('Login attempt:', { email, password });
            
            // Simulate successful login
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 1000);
        });
        
        document.getElementById('signup').addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('signupName').value;
            const email = document.getElementById('signupEmail').value;
            const password = document.getElementById('signupPassword').value;
            const confirmPassword = document.getElementById('signupConfirmPassword').value;
            
            if (password !== confirmPassword) {
                alert('Passwords do not match!');
                return;
            }
            
            if (!document.getElementById('terms').checked) {
                alert('You must agree to the terms and conditions');
                return;
            }
            
            // In a real app, you would send this to your backend
            console.log('Signup attempt:', { name, email, password });
            
            // Simulate successful signup
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 1000);
        });

        // get started js*\
        // Onboarding Steps Logic
        const steps = document.querySelectorAll('.step');
        const progressBar = document.getElementById('progressBar');
        let currentStep = 0;
        const totalSteps = steps.length;
        
        // Goal selection
        const goalCards = document.querySelectorAll('#step1 .option-card');
        let selectedGoal = null;
        
        goalCards.forEach(card => {
            card.addEventListener('click', function() {
                goalCards.forEach(c => c.classList.remove('selected'));
                this.classList.add('selected');
                selectedGoal = this.getAttribute('data-goal');
            });
        });
        
        // Step navigation
        document.getElementById('nextStep1').addEventListener('click', function() {
            if (!selectedGoal) {
                alert('Please select a health goal');
                return;
            }
            goToStep(1);
        });
        
        document.getElementById('backStep2').addEventListener('click', function() {
            goToStep(0);
        });
        
        document.getElementById('nextStep2').addEventListener('click', function() {
            if (!document.getElementById('personalInfoForm').checkValidity()) {
                alert('Please fill in all required fields');
                return;
            }
            goToStep(2);
        });
        
        document.getElementById('backStep3').addEventListener('click', function() {
            goToStep(1);
        });
        
        document.getElementById('nextStep3').addEventListener('click', function() {
            if (!document.getElementById('metricsForm').checkValidity()) {
                alert('Please fill in all required fields');
                return;
            }
            goToStep(3);
        });
        
        document.getElementById('backStep4').addEventListener('click', function() {
            goToStep(2);
        });
        
        document.getElementById('completeSignup').addEventListener('click', function() {
            if (!document.getElementById('accountForm').checkValidity()) {
                alert('Please fill in all required fields and agree to the terms');
                return;
            }
            
            if (document.getElementById('password').value !== document.getElementById('confirmPassword').value) {
                alert('Passwords do not match');
                return;
            }
            
            // In a real application, you would submit the data to your backend here
            // For this demo, we'll just proceed to the confirmation step
            goToStep(4);
        });
        
        function goToStep(stepIndex) {
            steps[currentStep].classList.remove('active');
            currentStep = stepIndex;
            steps[currentStep].classList.add('active');
            
            // Update progress bar
            const progressPercent = (currentStep / (totalSteps - 1)) * 100;
            progressBar.style.width = progressPercent + '%';
            
            // Scroll to top of step
            steps[currentStep].scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        //signup
        // Form validation
        document.getElementById('signupForm').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match!');
                document.getElementById('confirmPassword').focus();
            }
            
            // In a real application, you would also validate other fields
            // and potentially make an AJAX request to your backend
        });
        
        // Password strength indicator (optional enhancement)
        document.getElementById('password').addEventListener('input', function() {
            // You could add a password strength meter here
        });

        // learn more
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });


        // demo js
        // Sample heart rate chart
const heartRateCtx = document.createElement('canvas');
heartRateCtx.id = 'heartRateCanvas';
document.getElementById('heartRateChart').innerHTML = '';
document.getElementById('heartRateChart').appendChild(heartRateCtx);

new Chart(heartRateCtx, {
    type: 'line',
    data: {
        labels: ['12AM', '3AM', '6AM', '9AM', '12PM', '3PM', '6PM', '9PM'],
        datasets: [{
            label: 'Heart Rate',
            data: [62, 58, 60, 72, 75, 78, 72, 68],
            borderColor: '#e74c3c',
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: false
            }
        }
    }
});

// credit card payment 
// In your card payment form submission handler
document.getElementById('cardPaymentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Simulate payment processing
    const payBtn = this.querySelector('button[type="submit"]');
    payBtn.disabled = true;
    payBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing Payment...';
    
    // Simulate API call to payment gateway
    setTimeout(() => {
        // On successful payment
        const paymentSuccess = {
            status: 'success',
            transactionId: 'TXN' + Math.floor(Math.random() * 1000000),
            plan: getPlanFromURL() // Get plan from URL params
        };
        
        // Store payment data
        localStorage.setItem('paymentSuccess', JSON.stringify(paymentSuccess));
        
        // Redirect to dashboard
        window.location.href = 'dashboard.html';
    }, 2000);
});

function getPlanFromURL() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('plan') || 'premium';
}



// Sample blood pressure chart
const bloodPressureCtx = document.createElement('canvas');
bloodPressureCtx.id = 'bloodPressureCanvas';
document.getElementById('bloodPressureChart').innerHTML = '';
document.getElementById('bloodPressureChart').appendChild(bloodPressureCtx);
new Chart(bloodPressureCtx, {
    type: 'line',
    data: {
        labels: ['12AM', '3AM', '6AM', '9AM', '12PM', '3PM', '6PM', '9PM'],
        datasets: [{
            label: 'Blood Pressure',
            data: [120, 115, 118, 130, 125, 128, 122, 119],
            borderColor: '#3498db',
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: false
            }
        }
    }
});
// Sample sleep quality chart
const sleepQualityCtx = document.createElement('canvas');
sleepQualityCtx.id = 'sleepQualityCanvas';
document.getElementById('sleepQualityChart').innerHTML = '';        
document.getElementById('sleepQualityChart').appendChild(sleepQualityCtx);
new Chart(sleepQualityCtx, {
    type: 'bar',
    data: {
        labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
        datasets: [{
            label: 'Sleep Quality',
            data: [7, 6, 8, 5, 7, 9, 8],
            backgroundColor: '#2ecc71'
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: false
            }
        }
    }
});
// Sample step count chart
const stepCountCtx = document.createElement('canvas');
stepCountCtx.id = 'stepCountCanvas';
document.getElementById('stepCountChart').innerHTML = '';   
document.getElementById('stepCountChart').appendChild(stepCountCtx);
new Chart(stepCountCtx, {
    type: 'bar',
    data: {
        labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
        datasets: [{
            label: 'Step Count',
            data: [5000, 7000, 8000, 6000, 9000, 10000, 11000],
            backgroundColor: '#f39c12'
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: false
            }
        }
    }
});
